package com.example.sakib.lovecalculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b=(Button) findViewById(R.id.button);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void onClick(View v)
    {
        EditText t1= (EditText) findViewById(R.id.my_name);
        String s=t1.getText().toString();
        String s1= s.toLowerCase();
        EditText t2= (EditText) findViewById(R.id.v_name);
        String ss=t2.getText().toString();
        String s2=ss.toLowerCase();
        String result="0";
        boolean t=false;
        if(s1.isEmpty()||s2.isEmpty())
        {
            t=false;

        }
        else if((s1.equals("sakib")&&s2.equals("srity"))||(s1.equals("srity")&& s2.equals("sakib")))
        {
            result="100";
            t=true;
        }
        else
        {
            Random rand = new Random();
            result= String.valueOf((int) rand.nextInt(9)*10);
            t=true;
        }


        if(t)
        {
            Toast.makeText(getBaseContext(),"Calculated !",Toast.LENGTH_SHORT).show();
            TextView text= (TextView) findViewById(R.id.output);
            text.setText(new StringBuilder().append("Congratulation! \n").append("You are in Love with ").append(ss).append("\n").append("Love Parcentage :  ").append(result).append("%\n").append("Thank You \n").toString());
        }
        else
        {
            Toast.makeText(getBaseContext(),"Input both Name and try Again",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater info=getMenuInflater();
        info.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void open_info(){
        startActivity(new Intent(this,InfoActivity.class));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        open_info();
        return super.onOptionsItemSelected(item);
    }
}
